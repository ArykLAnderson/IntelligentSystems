There are no special installation instructions. I have this set up exactly how you recommended, 
though using Intellij, though that should not matter at all.