/**
 * Created by Aryk on 10/14/2015.
 */
public class Entity {
}
